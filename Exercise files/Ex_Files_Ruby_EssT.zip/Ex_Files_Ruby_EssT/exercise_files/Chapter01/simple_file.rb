puts 123
# print does not add a line return
   print 456    
puts    789