class Animal
  def make_noise
    "Moo!"
  end
end

animal = Animal.new
puts animal.make_noise
